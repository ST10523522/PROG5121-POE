/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registration;

/**
 *
 * @author HLENGI
 */
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;
public class Registration {

    public static void main(String[] args) {
       System.out.println("                Create an Account!");
        
       System.out.println("   ");
       
      
       System.out.println("Enter a new Username with atleast 5 characters and an underscore.");
        Scanner input = new Scanner(System.in);
        String username = input.nextLine();
        
        System.out.println("Enter a Password with atleast 8 characters,a capital letter,a number and a special character");
        String password = input.nextLine();
        
        System.out.println("Enter a Valid Rsa CellPhone Number");
        String cellphoneNumber = input.nextLine();
        
        
        System.out.println("      ");
        
        
        if(username.length() <= 5 && username.contains("_")) {
            System.out.println("Username captured successfully");
        } else {
            System.out.println("Username is not corretly formatted, please ensure that your Username contains 5 characters and an underscore!");
        }
        
        if(password.length() <= 8){
            System.out.println("Password captured successfully");
        } else {
            System.out.println("Password is not correctly formatted, please ensure that your Password contains 8 characters with atleast 1 capital letter,1 number and a 1 special number");
        }
        
        if(cellphoneNumber.length() == 12) {
            System.out.println("Cellphone number captured Successfully ");
        } else {
            System.out.println("Cellphone number incorrectly formatted or does not contain international code");
        }
    
        
 {
        
        
    }        
      
        }
    
    }
